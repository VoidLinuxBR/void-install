complete -c xpstree -f
