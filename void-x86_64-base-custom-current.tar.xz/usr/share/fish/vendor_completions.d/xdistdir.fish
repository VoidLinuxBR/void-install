complete -c xdistdir -f
