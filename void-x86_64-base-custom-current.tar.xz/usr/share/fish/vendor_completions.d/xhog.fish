complete -c xhog -f
