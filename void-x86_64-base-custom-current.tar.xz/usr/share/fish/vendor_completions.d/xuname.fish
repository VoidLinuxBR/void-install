complete -c xuname -f
