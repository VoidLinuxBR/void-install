complete -c xilog -f
