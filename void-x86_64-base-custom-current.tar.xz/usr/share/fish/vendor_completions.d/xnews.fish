complete -c xnews -f
