halt -w
